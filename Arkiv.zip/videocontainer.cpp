#include "videocontainer.h"
#include <gst/gst.h>
#include <gst/interfaces/xoverlay.h>
#include <QDebug>

VideoContainer::VideoContainer(QWidget *parent) :
    QWidget(parent)
{

}

void VideoContainer::initVideo(const char *videoURL){
    gst_init (NULL, NULL);

    // Creating the pipeline and the two sinks
    this->v_pipeline = gst_element_factory_make("playbin2", "player");
    GstElement *videosink = gst_element_factory_make("ximagesink", "video-sink");
    GstElement *audiosink = gst_element_factory_make("alsasink", "audiosink");
    if (NULL == this->v_pipeline || NULL == videosink || NULL == audiosink) {
        qDebug()<<"Error creating some of the sinks";
    }

    // Connect the audio and video sink, and setting the uri for the playbin2
    g_object_set(G_OBJECT(this->v_pipeline),"audio-sink", audiosink,"video-sink", videosink,NULL);
    g_object_set(G_OBJECT(this->v_pipeline), "video-sink", videosink, NULL);

    if(videoURL){
        g_object_set(G_OBJECT(this->v_pipeline), "uri",videoURL, NULL);
    } else {
        g_object_set(G_OBJECT(this->v_pipeline), "uri","http://docs.gstreamer.com/media/sintel_trailer-480p.webm", NULL);
    }


    gst_element_set_state(this->v_pipeline, GST_STATE_PLAYING);

    // Attatch the GStreamer video to the VideoContainer
    if(this->v_pipeline && GST_IS_X_OVERLAY(this->v_pipeline)){
        qDebug()<<"error";
        gst_x_overlay_set_window_handle(GST_X_OVERLAY(this->v_pipeline),this->winId());
    }
}

void VideoContainer::pauseVideo(){
    gst_element_set_state(this->v_pipeline, GST_STATE_PAUSED);
}
