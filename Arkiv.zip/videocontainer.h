#ifndef VIDEOCONTAINER_H
#define VIDEOCONTAINER_H

#include <QWidget>
#include <gst/gst.h>

class VideoContainer : public QWidget
{
    Q_OBJECT
public:
    explicit VideoContainer(QWidget *parent = 0);
    void initVideo(const char *);
    void pauseVideo();

private:
    GstElement *v_pipeline;

signals:

public slots:

};

#endif // VIDEOCONTAINER_H
