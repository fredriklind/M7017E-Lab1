#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "videocontainer.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->videocontainer->initVideo(NULL);

}

void MainWindow::on_pauseButton_clicked()
{
    ui->videocontainer->pauseVideo();
    ui->statusBar->showMessage("Video paused");
}

MainWindow::~MainWindow()
{
    delete ui;
}

